﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSFinal
{
    public partial class frmSearchPatient : Form
    {

        public static string myID = "";
        public frmSearchPatient()
        {
            InitializeComponent();
        }

        private void frmSearchPatient_Load(object sender, EventArgs e)
        {
            btnSearch.Enabled = false;
            
            // TODO: This line of code loads data into the 'finalPharmDataSet.Patient' table. You can move, or remove it, as needed.
            this.patientTableAdapter.Fill(this.finalPharmDataSet.Patient);

        }
        private void dgvPatientSearch_DoubleClick(object sender, EventArgs e)
        {
            string patientid = "";

            if (dgvPatientSearch.Rows.Count > 0)
            {
                DataGridViewRow row = dgvPatientSearch.SelectedRows[0];
                frmEditPatient afrom = new frmEditPatient();

                patientid = row.Cells[0].Value.ToString().Trim();
                myID = patientid;

                afrom.ShowDialog();

            }




        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string patientid = "";
            string Lname = "";
            string DOB = "";






            try
            {
                DataSet ds = new DataSet();
                PharmaDataTier patdid = new PharmaDataTier();
                patientid = txtPatientID.Text.Trim();
                Lname = txtLname.Text.Trim();
                DOB = txtDOB.Text.Trim();

                ds = patdid.GetPatient(patientid, Lname, DOB);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    dgvPatientSearch.Visible = true;


                    dgvPatientSearch.DataSource = ds.Tables[0];
                    dgvPatientSearch.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;

                    dgvPatientSearch.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    dgvPatientSearch.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;

                  



                }

                else
                {
                   

                }


            }
            catch (Exception ex)
            {
            }
        }

        private void dgvPatientSearch_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form aform = new frmAddPatient();
            aform.ShowDialog();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dgvPatientSearch_DoubleClick(sender, e);
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {

            DialogResult yesno = MessageBox.Show("Are you sure you want to delete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (yesno == DialogResult.Yes)
            {


                string patientid = "";
                try
                {
                    if (dgvPatientSearch.Rows.Count > 0)
                    {
                        DataGridViewRow row = dgvPatientSearch.SelectedRows[0];


                        patientid = row.Cells[0].Value.ToString().Trim();
                        myID = patientid;
                        DataSet ds = new DataSet();
                        PharmaDataTier studid = new PharmaDataTier();
                        patientid = myID.ToString();
                        studid.DeletePatient(patientid);
                        dgvPatientSearch.Refresh();
                        MessageBox.Show("Sucessfully Deleted!", "Done!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Cannot Delete Patient with active perscriptions", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("OK", "Not Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void txtPatientID_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) || (txtLname.Text.Trim().Length > 0) || (txtPatientID.Text.Trim().Length > 0))
            {
                btnSearch.Enabled = true;
            }
            else
            {
                btnSearch.Enabled = false;
            }
        }

        private void txtLname_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) || (txtLname.Text.Trim().Length > 0) || (txtPatientID.Text.Trim().Length > 0))
            {
                btnSearch.Enabled = true;
            }
            else
            {
                btnSearch.Enabled = false;
            }
        }

        private void txtDOB_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) || (txtLname.Text.Trim().Length > 0) || (txtPatientID.Text.Trim().Length > 0))
            {
                btnSearch.Enabled = true;
            }
            else
            {
                btnSearch.Enabled = false;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
