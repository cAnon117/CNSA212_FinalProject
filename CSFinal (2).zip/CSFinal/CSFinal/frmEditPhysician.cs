﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSFinal
{
    public partial class frmEditPhysician : Form
    {
        public frmEditPhysician()
        {
            InitializeComponent();
        }

        private void frmEditPhysician_Load(object sender, EventArgs e)
        {
            cboState.DataSource = StateManager.getStates();
            cboState.DisplayMember = "Name";
            cboState.ValueMember = "abbreviation";
            cboState.SelectedIndex = -1;



            try
            {
                DataSet ds = new DataSet();
                PharmaDataTier stuDT = new PharmaDataTier();

                ds = stuDT.GetPhysicianbyID(frmSearchPhysician.myID.ToString());


                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtPatientID.Text = ds.Tables[0].Rows[0]["physicianid"].ToString();
                    txtPatientID.Enabled = false;
                    txtFname.Text = ds.Tables[0].Rows[0]["fname"].ToString();
                    txtLname.Text = ds.Tables[0].Rows[0]["lname"].ToString();
                    txtDOB.Text = ds.Tables[0].Rows[0]["DOB"].ToString();
                    txtEmail.Text = ds.Tables[0].Rows[0]["email"].ToString();
                    txtStreet.Text = ds.Tables[0].Rows[0]["street"].ToString();
                    txtCity.Text = ds.Tables[0].Rows[0]["City"].ToString();
                    txtZip.Text = ds.Tables[0].Rows[0]["zipcode"].ToString();
                    txtCellphone.Text = ds.Tables[0].Rows[0]["cellphone"].ToString();





                }

            }
            catch (Exception ex)
            {

            }
        }

        private void btnPatientAdd_Click(object sender, EventArgs e)
        {
            string patientID = txtPatientID.Text.Trim();
            string fname = txtFname.Text.Trim();
            string lname = txtLname.Text.Trim();
            string midint = txtMidInit.Text.Trim();
            string email = txtEmail.Text.Trim();
            string home = txtHomePhone.Text.Trim();
            string cell = txtCellphone.Text.Trim();
            string street = txtStreet.Text.Trim();
            string city = txtCity.Text.Trim();
            string state = cboState.Text.Trim();
            string zip = txtZip.Text.Trim();
            string dob = txtDOB.Text.Trim();
            string gender = txtGender.Text.Trim().ToUpper();
            string licensing = txtLicenseNum.Text.Trim();


            PharmaDataTier patid = new PharmaDataTier();
            try
            {
                DateTime datecheck = DateTime.Parse(dob);

                try
                {
                    try
                    {
                        if ((txtMidInit.Text.Trim().Length == 1) || (txtMidInit.Text.Trim().Length == 0))
                        {


                            if ((gender.ToUpper() == "MALE") || (gender.ToUpper() == "FEMALE") || (gender.ToUpper() == "NA"))
                            {


                                patid.UpdatePhysician(patientID, fname, lname, midint, dob, gender, home, cell, email, street, city, state, zip, licensing);
                                MessageBox.Show("Physician Updatated!!! :3 >_<", "Complete!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                this.Close();


                            }
                            else
                            {
                                errorProvider1.SetError(txtGender, "Enter Vaild Gender or N/A");
                            }

                        }
                        else
                        {
                            errorProvider1.SetError(txtMidInit, "Only One Letter here");
                        }
                    }
                    catch (Exception ex)
                    {
                        errorProvider1.SetError(txtMidInit, "Only One Letter here");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error, Please enter Valid Values", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtDOB, "Please Enter a Valid Date");
            }
        }
    }
    
}
