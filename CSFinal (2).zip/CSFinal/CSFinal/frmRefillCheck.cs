﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSFinal
{
    public partial class frmRefillCheck : Form
    {
        public frmRefillCheck()
        {
            InitializeComponent();
        }
        public static string myID = "";

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Int32 refills = 0;
            string perscriptionID = "";






            try
            {
                DataSet ds = new DataSet();
                PharmaDataTier patdid = new PharmaDataTier();

                try
                {

                    if (txtRefillID.Text.Trim().Length > 0)
                    {

                        refills = Int32.Parse(txtRefillID.Text.Trim());

                        perscriptionID = txtPerscriptionID.Text.Trim();


                        ds = patdid.GetRefills(refills, perscriptionID);

                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            dgvRefills.Visible = true;


                            dgvRefills.DataSource = ds.Tables[0];
                            dgvRefills.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;

                            dgvRefills.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                            dgvRefills.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;





                        }
                    }
                    else
                    {
                        perscriptionID = txtPerscriptionID.Text.Trim();

                        ds = patdid.GetRefillbyID(perscriptionID);

                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            dgvRefills.Visible = true;


                            dgvRefills.DataSource = ds.Tables[0];
                            dgvRefills.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;

                            dgvRefills.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                            dgvRefills.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;


                        }


                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }




            }
            catch (Exception ex)
            {
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmRefillCheck_Load(object sender, EventArgs e)
        {
            btnSearch.Enabled = false;

            


        }

        private void txtRefillID_TextChanged(object sender, EventArgs e)
        {
            if ((txtPerscriptionID.Text.Trim().Length > 0) || (txtRefillID.Text.Trim().Length > 0))
            {
                btnSearch.Enabled = true;
            }
            else
            {
                btnSearch.Enabled = false;
            }
        }

        private void txtPerscriptionID_TextChanged(object sender, EventArgs e)
        {
            if ((txtPerscriptionID.Text.Trim().Length > 0) || (txtRefillID.Text.Trim().Length > 0))
            {
                btnSearch.Enabled = true;
            }
            else
            {
                btnSearch.Enabled = false;
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult yesno= MessageBox.Show("Are you sure you want to delete refill?", "Warning!!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (yesno == DialogResult.Yes)
            {
                int refillid = 0;
                string refill = "";
             
                string prescriptionID = "";
                try
                {
                    if (dgvRefills.Rows.Count > 0)
                    {
                        DataGridViewRow row = dgvRefills.SelectedRows[0];
                       
                        refill = row.Cells[0].Value.ToString().Trim();
                        refillid = Int32.Parse(refill);
                        
                        prescriptionID = row.Cells[1].Value.ToString().Trim();

                        
                        DataSet ds = new DataSet();
                        PharmaDataTier studid = new PharmaDataTier();
                        try
                        {


                            studid.DeleteRefill(refillid);
                            try
                            {


                                studid.UpdateNumofRefillsafterdelete(1, prescriptionID);

                                dgvRefills.Refresh();
                                MessageBox.Show("Sucessfully Deleted!", "Done!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Cannot Delete Patient with active perscriptions", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
