﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSFinal
{
    public partial class frmPerscription : Form
    {
        public frmPerscription()
        {
            InitializeComponent();
        }
        public static string myID = "";

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string patientid = "";
            string perscriptionID = "";






            try
            {
                DataSet ds = new DataSet();
                PharmaDataTier patdid = new PharmaDataTier();
                patientid = txtPatientID.Text.Trim();
                perscriptionID = txtPerscriptionID.Text.Trim();
  

                ds = patdid.GetPerscription(patientid, perscriptionID);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    dgvPerscription.Visible = true;


                    dgvPerscription.DataSource = ds.Tables[0];
                    dgvPerscription.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;

                    dgvPerscription.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    dgvPerscription.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;





                }

                else
                {


                }


            }
            catch (Exception ex)
            {
            }
        }

        private void mnuNew_Click(object sender, EventArgs e)
        {
            Form aform = new frmAddPerscription();
            aform.ShowDialog();
        }

        private void cmuDelete_Click(object sender, EventArgs e)
        {

            DialogResult yesno = MessageBox.Show("Are you sure you want to delete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (yesno == DialogResult.Yes)
            {


                string perscriptionid = "";
                try
                {
                    if (dgvPerscription.Rows.Count > 0)
                    {
                        DataGridViewRow row = dgvPerscription.SelectedRows[0];


                        perscriptionid = row.Cells[0].Value.ToString().Trim();
                        myID = perscriptionid;
                        DataSet ds = new DataSet();
                        PharmaDataTier studid = new PharmaDataTier();
                        perscriptionid = myID.ToString();
                        studid.DeletePerscription(perscriptionid);
                        dgvPerscription.Refresh();
                    }
                }
                catch (Exception ex)
                {

                }
            }
            else
            {
                MessageBox.Show("OK", "Not Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void frmPerscription_Load(object sender, EventArgs e)
        {
            btnSearch.Enabled = false;
        }

        private void txtPatientID_TextChanged(object sender, EventArgs e)
        {
            if ((txtPerscriptionID.Text.Trim().Length > 0) || (txtPatientID.Text.Trim().Length > 0))
            {
                btnSearch.Enabled = true;
            }
            else
            {
                btnSearch.Enabled = false;
            }
        }

        private void txtPerscriptionID_TextChanged(object sender, EventArgs e)
        {
            if ((txtPerscriptionID.Text.Trim().Length > 0) || (txtPatientID.Text.Trim().Length > 0))
            {
                btnSearch.Enabled = true;
            }
            else
            {
                btnSearch.Enabled = false;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void refillPrescriptionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string prescriptionID = "";
            int numofrefills = 0;
            string refills = "";

            if (dgvPerscription.Rows.Count > 0)
            {
                try
                {


                    PharmaDataTier preID = new PharmaDataTier();

                    DataGridViewRow row = dgvPerscription.SelectedRows[0];

                    prescriptionID = row.Cells[0].Value.ToString().Trim();
                    try
                    {


                        refills = row.Cells[3].Value.ToString().Trim();
                        numofrefills = Int32.Parse(refills);
                        numofrefills -= 1;
                        if (numofrefills > 0)
                        {


                            preID.insertrefill(prescriptionID);
                            preID.UpdateNumofRefills(numofrefills, prescriptionID);
                        }
                        else
                        {
                            MessageBox.Show("This Perscription is out of Refills and cannot be Complete", "No", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
