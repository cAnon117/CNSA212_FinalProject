﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSFinal
{
    public partial class frmSearchPhysician : Form
    {
        public static string myID = "";
        public frmSearchPhysician()
        {
            InitializeComponent();
        }
        private void dgvPhysician_DoubleClick(object sender, EventArgs e)
        {
            string physicianID = "";

            if (dgvPhysician.Rows.Count > 0)
            {
                DataGridViewRow row = dgvPhysician.SelectedRows[0];
                frmEditPhysician afrom = new frmEditPhysician();

                physicianID = row.Cells[1].Value.ToString().Trim();
                myID = physicianID;

                afrom.ShowDialog();

            }




        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string patientid = "";
            string Lname = "";
            string DOB = "";






            try
            {
                DataSet ds = new DataSet();
                PharmaDataTier patdid = new PharmaDataTier();
                patientid = txtPhysicianID.Text.Trim();
                Lname = txtLname.Text.Trim();
                DOB = txtDOB.Text.Trim();

                ds = patdid.GetPhysician(patientid, Lname, DOB);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    dgvPhysician.Visible = true;


                    dgvPhysician.DataSource = ds.Tables[0];
                    dgvPhysician.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;

                    dgvPhysician.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    dgvPhysician.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;





                }

                else
                {


                }


            }
            catch (Exception ex)
            {
            }
        }
     

        private void frmSearchPhysician_Load(object sender, EventArgs e)
        {
            btnSearch.Enabled = false;
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form aform = new frmAddPhysician();
            aform.ShowDialog();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dgvPhysician_DoubleClick(sender, e);
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult yesno = MessageBox.Show("Are you sure you want to delete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (yesno == DialogResult.Yes)
            {


                string pharmacistID = "";
                try
                {
                    if (dgvPhysician.Rows.Count > 0)
                    {
                        DataGridViewRow row = dgvPhysician.SelectedRows[0];


                        pharmacistID = row.Cells[1].Value.ToString().Trim();
                        myID = pharmacistID;
                        DataSet ds = new DataSet();
                        PharmaDataTier studid = new PharmaDataTier();
                        pharmacistID = myID.ToString();
                        studid.DeletePhysician(pharmacistID);
                        dgvPhysician.Refresh();
                    }
                }
                catch (Exception ex)
                {

                }
            }
            else
            {
                MessageBox.Show("OK", "Not Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void txtPhysicianID_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) || (txtLname.Text.Trim().Length > 0) || (txtPhysicianID.Text.Trim().Length > 0))
            {
                btnSearch.Enabled = true;
            }
            else
            {
                btnSearch.Enabled = false;
            }
        }

        private void txtLname_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) || (txtLname.Text.Trim().Length > 0) || (txtPhysicianID.Text.Trim().Length > 0))
            {
                btnSearch.Enabled = true;
            }
            else
            {
                btnSearch.Enabled = false;
            }
        }

        private void txtDOB_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) || (txtLname.Text.Trim().Length > 0) || (txtPhysicianID.Text.Trim().Length > 0))
            {
                btnSearch.Enabled = true;
            }
            else
            {
                btnSearch.Enabled = false;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
