﻿namespace CSFinal
{
    partial class frmRefillCheck
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRefillCheck));
            this.dgvRefills = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPerscriptionID = new System.Windows.Forms.TextBox();
            this.txtRefillID = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnClose = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.Refills = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrescriptionID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateRefilled = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnuDelete = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRefills)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvRefills
            // 
            this.dgvRefills.AllowUserToAddRows = false;
            this.dgvRefills.AllowUserToDeleteRows = false;
            this.dgvRefills.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRefills.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Refills,
            this.PrescriptionID,
            this.DateRefilled});
            this.dgvRefills.ContextMenuStrip = this.contextMenuStrip1;
            this.dgvRefills.Location = new System.Drawing.Point(141, 376);
            this.dgvRefills.Name = "dgvRefills";
            this.dgvRefills.RowHeadersWidth = 62;
            this.dgvRefills.RowTemplate.Height = 28;
            this.dgvRefills.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRefills.Size = new System.Drawing.Size(764, 271);
            this.dgvRefills.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(340, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 20);
            this.label4.TabIndex = 21;
            this.label4.Text = "RefillID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(292, 267);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 20);
            this.label2.TabIndex = 20;
            this.label2.Text = "PrescriptionID:";
            // 
            // txtPerscriptionID
            // 
            this.txtPerscriptionID.Location = new System.Drawing.Point(436, 264);
            this.txtPerscriptionID.Name = "txtPerscriptionID";
            this.txtPerscriptionID.Size = new System.Drawing.Size(100, 26);
            this.txtPerscriptionID.TabIndex = 1;
            this.txtPerscriptionID.TextChanged += new System.EventHandler(this.txtPerscriptionID_TextChanged);
            // 
            // txtRefillID
            // 
            this.txtRefillID.Location = new System.Drawing.Point(436, 197);
            this.txtRefillID.Name = "txtRefillID";
            this.txtRefillID.Size = new System.Drawing.Size(100, 26);
            this.txtRefillID.TabIndex = 0;
            this.txtRefillID.TextChanged += new System.EventHandler(this.txtRefillID_TextChanged);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(696, 197);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(114, 46);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.toolTip1.SetToolTip(this.btnSearch, "Click to Search");
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // btnClose
            // 
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(696, 280);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(114, 46);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "Close";
            this.toolTip1.SetToolTip(this.btnClose, "Click to Close");
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // Refills
            // 
            this.Refills.DataPropertyName = "Refills";
            this.Refills.HeaderText = "Refill ID";
            this.Refills.MinimumWidth = 8;
            this.Refills.Name = "Refills";
            this.Refills.Width = 150;
            // 
            // PrescriptionID
            // 
            this.PrescriptionID.DataPropertyName = "PrescriptionID";
            this.PrescriptionID.HeaderText = "PrescriptionID";
            this.PrescriptionID.MinimumWidth = 8;
            this.PrescriptionID.Name = "PrescriptionID";
            this.PrescriptionID.Width = 150;
            // 
            // DateRefilled
            // 
            this.DateRefilled.DataPropertyName = "DateRefilled";
            this.DateRefilled.HeaderText = "Date Refilled";
            this.DateRefilled.MinimumWidth = 8;
            this.DateRefilled.Name = "DateRefilled";
            this.DateRefilled.Width = 150;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuDelete});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(135, 36);
            // 
            // mnuDelete
            // 
            this.mnuDelete.Name = "mnuDelete";
            this.mnuDelete.Size = new System.Drawing.Size(134, 32);
            this.mnuDelete.Text = "Delete";
            this.mnuDelete.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // frmRefillCheck
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(1124, 678);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtPerscriptionID);
            this.Controls.Add(this.txtRefillID);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.dgvRefills);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmRefillCheck";
            this.Text = "Refill Checker";
            this.Load += new System.EventHandler(this.frmRefillCheck_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRefills)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvRefills;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPerscriptionID;
        private System.Windows.Forms.TextBox txtRefillID;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Refills;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrescriptionID;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateRefilled;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuDelete;
    }
}