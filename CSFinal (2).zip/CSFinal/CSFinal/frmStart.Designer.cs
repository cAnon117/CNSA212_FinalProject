﻿namespace CSFinal
{
    partial class frmStart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmStart));
            this.btnAddPatient = new System.Windows.Forms.Button();
            this.btnPatientSearch = new System.Windows.Forms.Button();
            this.btnAddPhysician = new System.Windows.Forms.Button();
            this.btnSearchPhysicians = new System.Windows.Forms.Button();
            this.btnAddPerscription = new System.Windows.Forms.Button();
            this.btnSearchPerscription = new System.Windows.Forms.Button();
            this.btnSeeRefill = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.tableAdapterManager1 = new CSFinal.FinalPharmDataSetTableAdapters.TableAdapterManager();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAddPatient = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAddPharmacist = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAddPerscription = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSearch = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSearchPatient = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSearchPharmacist = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSearchPerscription = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSearchRefills = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAddPatient
            // 
            this.btnAddPatient.Location = new System.Drawing.Point(200, 212);
            this.btnAddPatient.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAddPatient.Name = "btnAddPatient";
            this.btnAddPatient.Size = new System.Drawing.Size(112, 62);
            this.btnAddPatient.TabIndex = 0;
            this.btnAddPatient.Text = "Add New Patient";
            this.toolTip1.SetToolTip(this.btnAddPatient, "Click to Add Patient");
            this.btnAddPatient.UseVisualStyleBackColor = true;
            this.btnAddPatient.Click += new System.EventHandler(this.btnAddPatient_Click);
            // 
            // btnPatientSearch
            // 
            this.btnPatientSearch.Location = new System.Drawing.Point(200, 322);
            this.btnPatientSearch.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPatientSearch.Name = "btnPatientSearch";
            this.btnPatientSearch.Size = new System.Drawing.Size(112, 62);
            this.btnPatientSearch.TabIndex = 1;
            this.btnPatientSearch.Text = "Search Patients";
            this.toolTip1.SetToolTip(this.btnPatientSearch, "Click to Search Patient");
            this.btnPatientSearch.UseVisualStyleBackColor = true;
            this.btnPatientSearch.Click += new System.EventHandler(this.btnPatientSearch_Click);
            // 
            // btnAddPhysician
            // 
            this.btnAddPhysician.Location = new System.Drawing.Point(422, 212);
            this.btnAddPhysician.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAddPhysician.Name = "btnAddPhysician";
            this.btnAddPhysician.Size = new System.Drawing.Size(112, 62);
            this.btnAddPhysician.TabIndex = 2;
            this.btnAddPhysician.Text = "Add New Pharmacist";
            this.toolTip1.SetToolTip(this.btnAddPhysician, "Click to Add Pharmacist");
            this.btnAddPhysician.UseVisualStyleBackColor = true;
            this.btnAddPhysician.Click += new System.EventHandler(this.btnAddPhysician_Click);
            // 
            // btnSearchPhysicians
            // 
            this.btnSearchPhysicians.Location = new System.Drawing.Point(422, 322);
            this.btnSearchPhysicians.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSearchPhysicians.Name = "btnSearchPhysicians";
            this.btnSearchPhysicians.Size = new System.Drawing.Size(112, 62);
            this.btnSearchPhysicians.TabIndex = 3;
            this.btnSearchPhysicians.Text = "Search Pharmacists";
            this.toolTip1.SetToolTip(this.btnSearchPhysicians, "Click to Search Pharmacists");
            this.btnSearchPhysicians.UseVisualStyleBackColor = true;
            this.btnSearchPhysicians.Click += new System.EventHandler(this.btnSearchPhysicians_Click);
            // 
            // btnAddPerscription
            // 
            this.btnAddPerscription.Location = new System.Drawing.Point(636, 212);
            this.btnAddPerscription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAddPerscription.Name = "btnAddPerscription";
            this.btnAddPerscription.Size = new System.Drawing.Size(112, 62);
            this.btnAddPerscription.TabIndex = 4;
            this.btnAddPerscription.Text = "Add New Prescription";
            this.toolTip1.SetToolTip(this.btnAddPerscription, "Click to Add Prescription");
            this.btnAddPerscription.UseVisualStyleBackColor = true;
            this.btnAddPerscription.Click += new System.EventHandler(this.btnAddPerscription_Click);
            // 
            // btnSearchPerscription
            // 
            this.btnSearchPerscription.Location = new System.Drawing.Point(636, 322);
            this.btnSearchPerscription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSearchPerscription.Name = "btnSearchPerscription";
            this.btnSearchPerscription.Size = new System.Drawing.Size(112, 62);
            this.btnSearchPerscription.TabIndex = 5;
            this.btnSearchPerscription.Text = "Search Prescription";
            this.toolTip1.SetToolTip(this.btnSearchPerscription, "Click to Search Prescriptions");
            this.btnSearchPerscription.UseVisualStyleBackColor = true;
            this.btnSearchPerscription.Click += new System.EventHandler(this.btnSearchPerscription_Click);
            // 
            // btnSeeRefill
            // 
            this.btnSeeRefill.Location = new System.Drawing.Point(836, 212);
            this.btnSeeRefill.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSeeRefill.Name = "btnSeeRefill";
            this.btnSeeRefill.Size = new System.Drawing.Size(112, 62);
            this.btnSeeRefill.TabIndex = 6;
            this.btnSeeRefill.Text = "Check Refills";
            this.toolTip1.SetToolTip(this.btnSeeRefill, "Click To Check Refills");
            this.btnSeeRefill.UseVisualStyleBackColor = true;
            this.btnSeeRefill.Click += new System.EventHandler(this.btnSeeRefill_Click);
            // 
            // btnClose
            // 
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(836, 322);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(112, 62);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "Close";
            this.toolTip1.SetToolTip(this.btnClose, "Click to Close");
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.PatientTableAdapter = null;
            this.tableAdapterManager1.UpdateOrder = CSFinal.FinalPharmDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuAdd,
            this.mnuSearch,
            this.mnuHelp});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1200, 33);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnuAdd
            // 
            this.mnuAdd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuAddPatient,
            this.mnuAddPharmacist,
            this.mnuAddPerscription});
            this.mnuAdd.Name = "mnuAdd";
            this.mnuAdd.Size = new System.Drawing.Size(62, 29);
            this.mnuAdd.Text = "Add";
            // 
            // mnuAddPatient
            // 
            this.mnuAddPatient.Name = "mnuAddPatient";
            this.mnuAddPatient.Size = new System.Drawing.Size(245, 34);
            this.mnuAddPatient.Text = "Add Patient";
            this.mnuAddPatient.Click += new System.EventHandler(this.mnuAddPatient_Click);
            // 
            // mnuAddPharmacist
            // 
            this.mnuAddPharmacist.Name = "mnuAddPharmacist";
            this.mnuAddPharmacist.Size = new System.Drawing.Size(245, 34);
            this.mnuAddPharmacist.Text = "Add Pharmacist";
            this.mnuAddPharmacist.Click += new System.EventHandler(this.mnuAddPharmacist_Click);
            // 
            // mnuAddPerscription
            // 
            this.mnuAddPerscription.Name = "mnuAddPerscription";
            this.mnuAddPerscription.Size = new System.Drawing.Size(245, 34);
            this.mnuAddPerscription.Text = "Add Perscription";
            this.mnuAddPerscription.Click += new System.EventHandler(this.mnuAddPerscription_Click);
            // 
            // mnuSearch
            // 
            this.mnuSearch.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuSearchPatient,
            this.mnuSearchPharmacist,
            this.mnuSearchPerscription,
            this.mnuSearchRefills});
            this.mnuSearch.Name = "mnuSearch";
            this.mnuSearch.Size = new System.Drawing.Size(80, 29);
            this.mnuSearch.Text = "Search";
            // 
            // mnuSearchPatient
            // 
            this.mnuSearchPatient.Name = "mnuSearchPatient";
            this.mnuSearchPatient.Size = new System.Drawing.Size(263, 34);
            this.mnuSearchPatient.Text = "Search Patient";
            this.mnuSearchPatient.Click += new System.EventHandler(this.mnuSearchPatient_Click);
            // 
            // mnuSearchPharmacist
            // 
            this.mnuSearchPharmacist.Name = "mnuSearchPharmacist";
            this.mnuSearchPharmacist.Size = new System.Drawing.Size(263, 34);
            this.mnuSearchPharmacist.Text = "Search Pharmacist";
            this.mnuSearchPharmacist.Click += new System.EventHandler(this.mnuSearchPharmacist_Click);
            // 
            // mnuSearchPerscription
            // 
            this.mnuSearchPerscription.Name = "mnuSearchPerscription";
            this.mnuSearchPerscription.Size = new System.Drawing.Size(263, 34);
            this.mnuSearchPerscription.Text = "Search Perscription";
            this.mnuSearchPerscription.Click += new System.EventHandler(this.mnuSearchPerscription_Click);
            // 
            // mnuSearchRefills
            // 
            this.mnuSearchRefills.Name = "mnuSearchRefills";
            this.mnuSearchRefills.Size = new System.Drawing.Size(263, 34);
            this.mnuSearchRefills.Text = "Check Refills";
            this.mnuSearchRefills.Click += new System.EventHandler(this.mnuSearchRefills_Click);
            // 
            // mnuHelp
            // 
            this.mnuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.mnuHelp.Name = "mnuHelp";
            this.mnuHelp.Size = new System.Drawing.Size(65, 29);
            this.mnuHelp.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(164, 34);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(482, 99);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Welcome to our Pharmacy";
            // 
            // frmStart
            // 
            this.AcceptButton = this.btnAddPatient;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSeeRefill);
            this.Controls.Add(this.btnSearchPerscription);
            this.Controls.Add(this.btnAddPerscription);
            this.Controls.Add(this.btnSearchPhysicians);
            this.Controls.Add(this.btnAddPhysician);
            this.Controls.Add(this.btnPatientSearch);
            this.Controls.Add(this.btnAddPatient);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmStart";
            this.Text = "Start Page";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAddPatient;
        private System.Windows.Forms.Button btnPatientSearch;
        private System.Windows.Forms.Button btnAddPhysician;
        private System.Windows.Forms.Button btnSearchPhysicians;
        private System.Windows.Forms.Button btnAddPerscription;
        private System.Windows.Forms.Button btnSearchPerscription;
        private System.Windows.Forms.Button btnSeeRefill;
        private System.Windows.Forms.Button btnClose;
        private FinalPharmDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuAdd;
        private System.Windows.Forms.ToolStripMenuItem mnuAddPatient;
        private System.Windows.Forms.ToolStripMenuItem mnuAddPharmacist;
        private System.Windows.Forms.ToolStripMenuItem mnuAddPerscription;
        private System.Windows.Forms.ToolStripMenuItem mnuSearch;
        private System.Windows.Forms.ToolStripMenuItem mnuSearchPatient;
        private System.Windows.Forms.ToolStripMenuItem mnuSearchPharmacist;
        private System.Windows.Forms.ToolStripMenuItem mnuSearchPerscription;
        private System.Windows.Forms.ToolStripMenuItem mnuSearchRefills;
        private System.Windows.Forms.ToolStripMenuItem mnuHelp;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Label label1;
    }
}