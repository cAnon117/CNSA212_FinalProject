﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSFinal
{
    public partial class frmAddPatient : Form
    {
        public frmAddPatient()
        {
            InitializeComponent();
        }
        private void clear()
        {
            txtPatientID.Text = "";
            txtFname.Text = "";
            txtLname.Text = "";
            txtMidInit.Text = "";
            txtEmail.Text = "";
            txtHomePhone.Text = "";
            txtCellphone.Text = "";
            txtStreet.Text = "";
            txtCity.Text = "";
            cboState.SelectedIndex = -1;
            txtZip.Text = "";
            txtDOB.Text = "";
            txtGender.Text = "";
            txtPatientID.Focus();
            btnPatientAdd.Enabled = false;
            errorProvider1.Clear();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmAddPatient_Load(object sender, EventArgs e)
        {
            cboState.DataSource = StateManager.getStates();
            cboState.DisplayMember = "Name";
            cboState.ValueMember = "abbreviation";
            cboState.SelectedIndex = -1;
            btnPatientAdd.Enabled = false;
        }

        private void btnPatientAdd_Click(object sender, EventArgs e)
        {
            string patientID = txtPatientID.Text.Trim();
            string fname = txtFname.Text.Trim();
            string lname = txtLname.Text.Trim();
            string midint = txtMidInit.Text.Trim();
            string email = txtEmail.Text.Trim();
            string home = txtHomePhone.Text.Trim();
            string cell = txtCellphone.Text.Trim();
            string street = txtStreet.Text.Trim();
            string city = txtCity.Text.Trim();
            string state = cboState.Text.Trim();
            string zip = txtZip.Text.Trim();
            string dob = txtDOB.Text.Trim();
            string gender = txtGender.Text.Trim().ToUpper();
            PharmaDataTier patid = new PharmaDataTier();
            try
            {
                DateTime datecheck = DateTime.Parse(dob);

                try
                {
                    try
                    {
                        if ((txtMidInit.Text.Trim().Length == 1) || (txtMidInit.Text.Trim().Length == 0))
                        {


                            if ((gender.ToUpper() == "MALE") || (gender.ToUpper() == "FEMALE") || (gender.ToUpper() == "NA"))
                            {


                                patid.insertPatient(patientID, fname, lname, midint, dob, gender, home, cell, email, street, city, state, zip);
                                MessageBox.Show("Successfully ADDED :3 >_<", "Complete!", MessageBoxButtons.OK, MessageBoxIcon.Information);


                            }
                            else
                            {
                                errorProvider1.SetError(txtGender, "Enter Vaild Gender or N/A");
                            }
                            clear();
                        }
                        else
                        {
                            errorProvider1.SetError(txtMidInit, "Only One Letter here");
                        }
                    }
                    catch (Exception ex)
                    {
                        errorProvider1.SetError(txtMidInit, "Only One Letter here");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error, Please enter Valid Values", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtDOB, "Please Enter a Valid Date");
            }
        }

        private void txtFname_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) && (txtLname.Text.Trim().Length > 0) && (txtPatientID.Text.Trim().Length > 0) && (txtGender.Text.Trim().Length > 0) && (txtDOB.Text.Trim().Length > 0))
            {
                btnPatientAdd.Enabled = true;
            }
            else
            {
                btnPatientAdd.Enabled = false;
            }
        }

        private void txtLname_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) && (txtLname.Text.Trim().Length > 0) && (txtPatientID.Text.Trim().Length > 0) && (txtGender.Text.Trim().Length > 0) && (txtDOB.Text.Trim().Length > 0))
            {
                btnPatientAdd.Enabled = true;
            }
            else
            {
                btnPatientAdd.Enabled = false;
            }
        }

        private void txtDOB_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) && (txtLname.Text.Trim().Length > 0) && (txtPatientID.Text.Trim().Length > 0) && (txtGender.Text.Trim().Length > 0) && (txtDOB.Text.Trim().Length > 0))
            {
                btnPatientAdd.Enabled = true;
            }
            else
            {
                btnPatientAdd.Enabled = false;
            }
        }

        private void txtGender_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) && (txtLname.Text.Trim().Length > 0) && (txtPatientID.Text.Trim().Length > 0) && (txtGender.Text.Trim().Length > 0) && (txtDOB.Text.Trim().Length > 0))
            {
                btnPatientAdd.Enabled = true;
            }
            else
            {
                btnPatientAdd.Enabled = false;
            }
        }

        private void txtPatientID_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) && (txtLname.Text.Trim().Length > 0) && (txtPatientID.Text.Trim().Length > 0) && (txtGender.Text.Trim().Length > 0) && (txtDOB.Text.Trim().Length > 0))
            {
                btnPatientAdd.Enabled = true;
            }
            else
            {
                btnPatientAdd.Enabled = false;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clear();
        }
    }
}
