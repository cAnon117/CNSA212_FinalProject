﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Data.SqlClient;

namespace CSFinal
{
    internal class PharmaDataTier
    {
        static String connString = ConfigurationManager.ConnectionStrings["ConnString"].ConnectionString;
        static SqlConnection myConn = new SqlConnection(connString);
        static System.Data.SqlClient.SqlCommand cmdString = new System.Data.SqlClient.SqlCommand();


        public DataSet GetPatient(string patdid, string patLname, string patDOB)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "selectpatient";
                //        Define input parameter
                cmdString.Parameters.Add("@patientID", SqlDbType.VarChar, 6).Value = patdid;
                cmdString.Parameters.Add("@Lname", SqlDbType.VarChar, 25).Value = patLname;
                cmdString.Parameters.Add("@DOB", SqlDbType.VarChar, 16).Value = patDOB;
                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();

                aAdapter.SelectCommand = cmdString;
                DataSet aDataSet = new DataSet();

                // fill adapater
                aAdapter.Fill(aDataSet);

                //        return dataSet
                return aDataSet;
            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }

        }
        public DataSet GetPatientbyID(string patdid)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "getPatbyID";
                //        Define input parameter
                cmdString.Parameters.Add("@patientID", SqlDbType.VarChar, 6).Value = patdid;

                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();

                aAdapter.SelectCommand = cmdString;
                DataSet aDataSet = new DataSet();

                // fill adapater
                aAdapter.Fill(aDataSet);

                //        return dataSet
                return aDataSet;
            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }

        }
        public DataSet GetPhysicianbyID(string patdid)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "getPhysicianbyID";
                //        Define input parameter
                cmdString.Parameters.Add("@physician", SqlDbType.VarChar, 6).Value = patdid;

                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();

                aAdapter.SelectCommand = cmdString;
                DataSet aDataSet = new DataSet();

                // fill adapater
                aAdapter.Fill(aDataSet);

                //        return dataSet
                return aDataSet;
            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }

        }

        public DataSet GetPhysician(string patdid, string patLname, string patDOB)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "selectphysician";
                //        Define input parameter
                cmdString.Parameters.Add("@PhysicianID", SqlDbType.VarChar, 6).Value = patdid;
                cmdString.Parameters.Add("@Lname", SqlDbType.VarChar, 25).Value = patLname;
                cmdString.Parameters.Add("@DOB", SqlDbType.VarChar, 16).Value = patDOB;
                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();

                aAdapter.SelectCommand = cmdString;
                DataSet aDataSet = new DataSet();

                // fill adapater
                aAdapter.Fill(aDataSet);

                //        return dataSet
                return aDataSet;
            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }

        }


        public DataSet GetPerscription(string patdid, string perscription)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "searchperscription";
                //        Define input parameter
                cmdString.Parameters.Add("@PatientID", SqlDbType.VarChar, 6).Value = patdid;
                cmdString.Parameters.Add("@PerscriptionID", SqlDbType.VarChar, 6).Value = perscription;
                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();

                aAdapter.SelectCommand = cmdString;
                DataSet aDataSet = new DataSet();

                // fill adapater
                aAdapter.Fill(aDataSet);

                //        return dataSet
                return aDataSet;
            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }

        }
        public DataSet GetRefills(Int32 refills, string perscription)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "searchrefills";
                //        Define input parameter
                cmdString.Parameters.Add("@refill", SqlDbType.Int).Value = refills;
                cmdString.Parameters.Add("@PerscriptionID", SqlDbType.VarChar, 6).Value = perscription;
                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();

                aAdapter.SelectCommand = cmdString;
                DataSet aDataSet = new DataSet();

                // fill adapater
                aAdapter.Fill(aDataSet);

                //        return dataSet
                return aDataSet;
            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }

        }
        public void insertPatient(string patdids, string fname, string lname, string MI, string DOB, string gender, string home, string cell, string email, string street, string city, string state, string zip)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "insertpatient";
                //        Define input parameter
                cmdString.Parameters.Add("@patientid", SqlDbType.VarChar, 6).Value = patdids;
                cmdString.Parameters.Add("@fname", SqlDbType.VarChar, 25).Value = fname;
                cmdString.Parameters.Add("@lname", SqlDbType.VarChar, 25).Value = lname;
                cmdString.Parameters.Add("@MI", SqlDbType.Char, 1).Value = MI;
                cmdString.Parameters.Add("@DOB", SqlDbType.VarChar, 16).Value = DOB;
                cmdString.Parameters.Add("@homephone", SqlDbType.VarChar, 11).Value = home;
                cmdString.Parameters.Add("@gender", SqlDbType.Char, 6).Value = gender;
                cmdString.Parameters.Add("@cellphone", SqlDbType.VarChar, 11).Value = cell;
                cmdString.Parameters.Add("@email", SqlDbType.VarChar, 50).Value = email;
                cmdString.Parameters.Add("@Street", SqlDbType.VarChar, 25).Value = street;
                cmdString.Parameters.Add("@city", SqlDbType.VarChar, 25).Value = city;
                cmdString.Parameters.Add("@state", SqlDbType.VarChar, 25).Value = state;
                cmdString.Parameters.Add("@zip", SqlDbType.VarChar, 25).Value = zip;

                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();
                cmdString.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }

        }

        public void insertPhysician(string patdids, string fname, string lname, string MI, string DOB, string gender, string home, string cell, string email, string street, string city, string state, string zip, string licensing)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "insertphysician";
                //        Define input parameter
                cmdString.Parameters.Add("@physicianid", SqlDbType.VarChar, 6).Value = patdids;
                cmdString.Parameters.Add("@fname", SqlDbType.VarChar, 25).Value = fname;
                cmdString.Parameters.Add("@lname", SqlDbType.VarChar, 25).Value = lname;
                cmdString.Parameters.Add("@MI", SqlDbType.Char, 1).Value = MI;
                cmdString.Parameters.Add("@DOB", SqlDbType.VarChar, 16).Value = DOB;
                cmdString.Parameters.Add("@homephone", SqlDbType.VarChar, 11).Value = home;
                cmdString.Parameters.Add("@gender", SqlDbType.Char, 6).Value = gender;
                cmdString.Parameters.Add("@cellphone", SqlDbType.VarChar, 11).Value = cell;
                cmdString.Parameters.Add("@email", SqlDbType.VarChar, 50).Value = email;
                cmdString.Parameters.Add("@Street", SqlDbType.VarChar, 25).Value = street;
                cmdString.Parameters.Add("@city", SqlDbType.VarChar, 25).Value = city;
                cmdString.Parameters.Add("@state", SqlDbType.VarChar, 25).Value = state;
                cmdString.Parameters.Add("@zip", SqlDbType.VarChar, 25).Value = zip;
                cmdString.Parameters.Add("@licensing", SqlDbType.VarChar, 15).Value = licensing;

                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();
                cmdString.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }

        }
        public void insertpercription(string perscriptionID, string rxname, string rxdosage, string patientID, string refills)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "InsertRealPrescription";
                //        Define input parameter
                cmdString.Parameters.Add("@perscriptionid", SqlDbType.VarChar, 6).Value = perscriptionID;
                cmdString.Parameters.Add("@rxname", SqlDbType.VarChar, 25).Value = rxname;
                cmdString.Parameters.Add("@rxdosage", SqlDbType.Int).Value = rxdosage;
                cmdString.Parameters.Add("@patientID", SqlDbType.VarChar, 6).Value = patientID;
                cmdString.Parameters.Add("@NumOfRefills", SqlDbType.Int).Value = refills;

                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();
                cmdString.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }



        }
        public void insertrefill(string perscriptionID)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "addRealRefill";
                //        Define input parameter
                cmdString.Parameters.Add("@prescriptionid", SqlDbType.VarChar, 6).Value = perscriptionID;


                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();
                cmdString.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }



        }




        public void UpdatePatient(string patdids, string fname, string lname, string MI, string DOB, string gender, string home, string cell, string email, string street, string city, string state, string zip)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "updatepatient";
                //        Define input parameter
                cmdString.Parameters.Add("@patid", SqlDbType.VarChar, 6).Value = patdids;
                cmdString.Parameters.Add("@fname", SqlDbType.VarChar, 25).Value = fname;
                cmdString.Parameters.Add("@lname", SqlDbType.VarChar, 25).Value = lname;
                cmdString.Parameters.Add("@MI", SqlDbType.Char, 1).Value = MI;
                cmdString.Parameters.Add("@DOB", SqlDbType.VarChar, 16).Value = DOB;
                cmdString.Parameters.Add("@home", SqlDbType.VarChar, 11).Value = home;
                cmdString.Parameters.Add("@gender", SqlDbType.Char, 6).Value = gender;
                cmdString.Parameters.Add("@cell", SqlDbType.VarChar, 11).Value = cell;
                cmdString.Parameters.Add("@email", SqlDbType.VarChar, 50).Value = email;
                cmdString.Parameters.Add("@Street", SqlDbType.VarChar, 25).Value = street;
                cmdString.Parameters.Add("@city", SqlDbType.VarChar, 25).Value = city;
                cmdString.Parameters.Add("@state", SqlDbType.VarChar, 25).Value = state;
                cmdString.Parameters.Add("@zip", SqlDbType.VarChar, 25).Value = zip;

                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();
                cmdString.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }


        }

        public void UpdatePhysician(string patdids, string fname, string lname, string MI, string DOB, string gender, string home, string cell, string email, string street, string city, string state, string zip, string licensing)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "updatePhysician";
                //        Define input parameter
                cmdString.Parameters.Add("@patid", SqlDbType.VarChar, 6).Value = patdids;
                cmdString.Parameters.Add("@fname", SqlDbType.VarChar, 25).Value = fname;
                cmdString.Parameters.Add("@lname", SqlDbType.VarChar, 25).Value = lname;
                cmdString.Parameters.Add("@MI", SqlDbType.Char, 1).Value = MI;
                cmdString.Parameters.Add("@DOB", SqlDbType.VarChar, 16).Value = DOB;
                cmdString.Parameters.Add("@home", SqlDbType.VarChar, 11).Value = home;
                cmdString.Parameters.Add("@gender", SqlDbType.Char, 6).Value = gender;
                cmdString.Parameters.Add("@cell", SqlDbType.VarChar, 11).Value = cell;
                cmdString.Parameters.Add("@email", SqlDbType.VarChar, 50).Value = email;
                cmdString.Parameters.Add("@Street", SqlDbType.VarChar, 25).Value = street;
                cmdString.Parameters.Add("@city", SqlDbType.VarChar, 25).Value = city;
                cmdString.Parameters.Add("@state", SqlDbType.VarChar, 25).Value = state;
                cmdString.Parameters.Add("@zip", SqlDbType.VarChar, 25).Value = zip;
                cmdString.Parameters.Add("@license", SqlDbType.VarChar, 25).Value = licensing;

                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();
                cmdString.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }



        }

        public void DeletePatient(string studentID)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "deletePatient";
                //        Define input parameter
                cmdString.Parameters.Add("@patientID", SqlDbType.VarChar, 6).Value = studentID;

                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();
                cmdString.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }



        }
        public void DeletePhysician(string physicianID)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "deletephysician";
                //        Define input parameter
                cmdString.Parameters.Add("@physicianID", SqlDbType.VarChar, 6).Value = physicianID;

                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();
                cmdString.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }



        }
        public void DeletePerscription(string perscriptionID)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "deleteperscription";
                //        Define input parameter
                cmdString.Parameters.Add("@perscriptionID", SqlDbType.VarChar, 6).Value = perscriptionID;

                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();
                cmdString.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }



        }


        public void UpdateNumofRefills(int numofrefills, string PrescriptionID)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "updatenumofrefills";
                //        Define input parameter
                cmdString.Parameters.Add("@numofrefills", SqlDbType.Int).Value = numofrefills;
                cmdString.Parameters.Add("@prescriptionID", SqlDbType.VarChar, 6).Value = PrescriptionID;
                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();
                cmdString.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }


        }


        public void UpdateNumofRefillsafterdelete(int numofrefills, string PrescriptionID)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "addtoprescription";
                //        Define input parameter
                cmdString.Parameters.Add("@numofrefills", SqlDbType.Int).Value = numofrefills;
                cmdString.Parameters.Add("@prescriptionID", SqlDbType.VarChar, 6).Value = PrescriptionID;
                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();
                cmdString.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }


        }

        public void DeleteRefill(int refillid)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "deleterefill";
                //        Define input parameter
                cmdString.Parameters.Add("@refillID", SqlDbType.VarChar, 6).Value = refillid;

                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();
                cmdString.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }



        }


        public DataSet GetRefillbyID(string prescriptionID)
        {

            try
            {

                // open connection
                myConn.Open();
                //clear any parameters
                cmdString.Parameters.Clear();
                // command
                cmdString.Connection = myConn;
                cmdString.CommandType = CommandType.StoredProcedure;
                cmdString.CommandTimeout = 1500;
                cmdString.CommandText = "getrefillbyid";
                //        Define input parameter
                cmdString.Parameters.Add("@perscriptionID", SqlDbType.VarChar, 6).Value = prescriptionID;
                //        adapter and dataset
                SqlDataAdapter aAdapter = new SqlDataAdapter();

                aAdapter.SelectCommand = cmdString;
                DataSet aDataSet = new DataSet();

                // fill adapater
                aAdapter.Fill(aDataSet);

                //        return dataSet
                return aDataSet;
            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
            finally
            {
                myConn.Close();
            }

        }



    }

}
