﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSFinal
{
    public partial class frmAddPerscription : Form
    {
        public frmAddPerscription()
        {
            InitializeComponent();
        }

        private void clear()
        {
            txtPatientID.Text = string.Empty;
            txtPerscriptionID.Text = string.Empty;
            txtRefills.Text = string.Empty;
            txtRXDosage.Text = string.Empty;
            txtRXName.Text = string.Empty;
            txtPerscriptionID.Focus();
            btnAddPerscription.Enabled = false;
        }


        private void btnAddPerscription_Click(object sender, EventArgs e)
        {
            string perscriptionID = txtPerscriptionID.Text.Trim();
            string rxname = txtRXName.Text.Trim();
            string rxdosage = txtRXDosage.Text.Trim();
            string num = txtRefills.Text.Trim();
            string patientID = txtPatientID.Text.Trim();

            try
            {
                PharmaDataTier patid = new PharmaDataTier();

                patid.insertpercription(perscriptionID, rxname, rxdosage, patientID, num);
                


            }
            catch (Exception ex)
            {
                MessageBox.Show("Perscription Information Invalid", "Error!", MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void txtPerscriptionID_TextChanged(object sender, EventArgs e)
        {
            if ((txtPerscriptionID.Text.Trim().Length > 0) && (txtPatientID.Text.Trim().Length > 0) && (txtRefills.Text.Trim().Length > 0) && (txtRXName.Text.Trim().Length > 0) && (txtRXDosage.Text.Trim().Length > 0))
            {
                btnAddPerscription.Enabled = true;
            }
            else
            {
                btnAddPerscription.Enabled = true;
            }
        }

        private void txtRXName_TextChanged(object sender, EventArgs e)
        {

            if ((txtPerscriptionID.Text.Trim().Length > 0) && (txtPatientID.Text.Trim().Length > 0) && (txtRefills.Text.Trim().Length > 0) && (txtRXName.Text.Trim().Length > 0) && (txtRXDosage.Text.Trim().Length > 0))
            {
                btnAddPerscription.Enabled = true;
            }
            else
            {
                btnAddPerscription.Enabled = true;
            }
        }

        private void txtRXDosage_TextChanged(object sender, EventArgs e)
        {
            if ((txtPerscriptionID.Text.Trim().Length > 0) && (txtPatientID.Text.Trim().Length > 0) && (txtRefills.Text.Trim().Length > 0) && (txtRXName.Text.Trim().Length > 0) && (txtRXDosage.Text.Trim().Length > 0))
            {
                btnAddPerscription.Enabled = true;
            }
            else
            {
                btnAddPerscription.Enabled = true;
            }
        }

        private void txtPatientID_TextChanged(object sender, EventArgs e)
        {
            if ((txtPerscriptionID.Text.Trim().Length > 0) && (txtPatientID.Text.Trim().Length > 0) && (txtRefills.Text.Trim().Length > 0) && (txtRXName.Text.Trim().Length > 0) && (txtRXDosage.Text.Trim().Length > 0))
            {
                btnAddPerscription.Enabled = true;
            }
            else
            {
                btnAddPerscription.Enabled = true;
            }
        }

        private void txtRefills_TextChanged(object sender, EventArgs e)
        {
            if ((txtPerscriptionID.Text.Trim().Length > 0) && (txtPatientID.Text.Trim().Length > 0) && (txtRefills.Text.Trim().Length > 0) && (txtRXName.Text.Trim().Length > 0) && (txtRXDosage.Text.Trim().Length > 0))
            {
                btnAddPerscription.Enabled = true;
            }
            else
            {
                btnAddPerscription.Enabled = true;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clear();
        }
    }
}
