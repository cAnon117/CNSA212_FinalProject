﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSFinal
{
    public partial class frmAddPhysician : Form
    {
        public frmAddPhysician()
        {
            InitializeComponent();
        }
        private void clear()
        {
            txtPhysicianID.Text = "";
            txtFname.Text = "";
            txtLname.Text = "";
            txtMidInit.Text = "";
            txtEmail.Text = "";
            txtHomePhone.Text = "";
            txtCellphone.Text = "";
            txtStreet.Text = "";
            txtCity.Text = "";
            cboState.SelectedIndex = -1;
            txtZip.Text = "";
            txtDOB.Text = "";
            txtGender.Text = "";
            txtPhysicianID.Focus();
            btnPhysicianAdd.Enabled = false;
            txtLicenseNum.Text = "";
            errorProvider1.Clear();
        }
        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmAddPhysician_Load(object sender, EventArgs e)
        {
            cboState.DataSource = StateManager.getStates();
            cboState.DisplayMember = "Name";
            cboState.ValueMember = "abbreviation";
            cboState.SelectedIndex = -1;
            btnPhysicianAdd.Enabled = false;
        }

        private void btnPatientAdd_Click(object sender, EventArgs e)
        {
            string patientID = txtPhysicianID.Text.Trim();
            string fname = txtFname.Text.Trim();
            string lname = txtLname.Text.Trim();
            string midint = txtMidInit.Text.Trim();
            string email = txtEmail.Text.Trim();
            string home = txtHomePhone.Text.Trim();
            string cell = txtCellphone.Text.Trim();
            string street = txtStreet.Text.Trim();
            string city = txtCity.Text.Trim();
            string state = cboState.Text.Trim();
            string zip = txtZip.Text.Trim();
            string dob = txtDOB.Text.Trim();
            string gender = txtGender.Text.Trim().ToUpper();
            string license = txtLicenseNum.Text.Trim();
            PharmaDataTier patid = new PharmaDataTier();
            try
            {
                DateTime datecheck = DateTime.Parse(dob);

                try
                {
                    try
                    {
                        if ((txtMidInit.Text.Trim().Length == 1) || (txtMidInit.Text.Trim().Length == 0))
                        {



                            if ((gender.ToUpper() == "MALE") || (gender.ToUpper() == "FEMALE") || (gender.ToUpper() == "NA"))
                            {


                                patid.insertPhysician(patientID, fname, lname, midint, dob, gender, home, cell, email, street, city, state, zip, license);
                                MessageBox.Show("Successfully ADDED :3 >_<", "Complete!", MessageBoxButtons.OK, MessageBoxIcon.Information);


                            }
                            else
                            {
                                errorProvider1.SetError(txtGender, "Enter Vaild Gender or N/A");
                            }
                            clear();
                        }
                        else
                        {
                            errorProvider1.SetError(txtMidInit, "Only One Letter Can be here!!");
                        }
                    }
                    catch (Exception ex)
                    {
                        errorProvider1.SetError(txtMidInit, "Only One Letter Can be here!!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error, Please enter Valid Values", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtDOB, "Please Enter a Valid Date");
            }
        }

        private void txtFname_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) && (txtLname.Text.Trim().Length > 0) && (txtPhysicianID.Text.Trim().Length > 0) && (txtGender.Text.Trim().Length > 0) && (txtDOB.Text.Trim().Length > 0))
            {
                btnPhysicianAdd.Enabled = true;
            }
            else
            {
                btnPhysicianAdd.Enabled = false;
            }
        }

        private void txtLname_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) && (txtLname.Text.Trim().Length > 0) && (txtPhysicianID.Text.Trim().Length > 0) && (txtGender.Text.Trim().Length > 0) && (txtDOB.Text.Trim().Length > 0))
            {
                btnPhysicianAdd.Enabled = true;
            }
            else
            {
                btnPhysicianAdd.Enabled = false;
            }
        }

        private void txtDOB_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) && (txtLname.Text.Trim().Length > 0) && (txtPhysicianID.Text.Trim().Length > 0) && (txtGender.Text.Trim().Length > 0) && (txtDOB.Text.Trim().Length > 0))
            {
                btnPhysicianAdd.Enabled = true;
            }
            else
            {
                btnPhysicianAdd.Enabled = false;
            }
        }

        private void txtGender_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) && (txtLname.Text.Trim().Length > 0) && (txtPhysicianID.Text.Trim().Length > 0) && (txtGender.Text.Trim().Length > 0) && (txtDOB.Text.Trim().Length > 0))
            {
                btnPhysicianAdd.Enabled = true;
            }
            else
            {
                btnPhysicianAdd.Enabled = false;
            }
        }

        private void txtPhysicianID_TextChanged(object sender, EventArgs e)
        {
            if ((txtDOB.Text.Trim().Length > 0) && (txtLname.Text.Trim().Length > 0) && (txtPhysicianID.Text.Trim().Length > 0) && (txtGender.Text.Trim().Length > 0) && (txtDOB.Text.Trim().Length > 0))
            {
                btnPhysicianAdd.Enabled = true;
            }
            else
            {
                btnPhysicianAdd.Enabled = false;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clear();
        }
    }
}
