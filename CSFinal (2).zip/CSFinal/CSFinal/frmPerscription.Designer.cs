﻿namespace CSFinal
{
    partial class frmPerscription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPerscription));
            this.dgvPerscription = new System.Windows.Forms.DataGridView();
            this.PrescriptionID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NumOfRefills = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RXName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RXDosage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnuNew = new System.Windows.Forms.ToolStripMenuItem();
            this.cmuDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.refillPrescriptionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPerscriptionID = new System.Windows.Forms.TextBox();
            this.txtPatientID = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPerscription)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvPerscription
            // 
            this.dgvPerscription.AllowUserToAddRows = false;
            this.dgvPerscription.AllowUserToDeleteRows = false;
            this.dgvPerscription.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPerscription.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PrescriptionID,
            this.NumOfRefills,
            this.RXName,
            this.RXDosage});
            this.dgvPerscription.ContextMenuStrip = this.contextMenuStrip1;
            this.dgvPerscription.Location = new System.Drawing.Point(111, 350);
            this.dgvPerscription.Name = "dgvPerscription";
            this.dgvPerscription.RowHeadersWidth = 62;
            this.dgvPerscription.RowTemplate.Height = 28;
            this.dgvPerscription.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPerscription.Size = new System.Drawing.Size(893, 250);
            this.dgvPerscription.TabIndex = 0;
            // 
            // PrescriptionID
            // 
            this.PrescriptionID.DataPropertyName = "PrescriptionID";
            this.PrescriptionID.HeaderText = "PrescriptionID";
            this.PrescriptionID.MinimumWidth = 8;
            this.PrescriptionID.Name = "PrescriptionID";
            this.PrescriptionID.Width = 150;
            // 
            // NumOfRefills
            // 
            this.NumOfRefills.DataPropertyName = "NumOfRefills";
            this.NumOfRefills.HeaderText = "Refills Left";
            this.NumOfRefills.MinimumWidth = 8;
            this.NumOfRefills.Name = "NumOfRefills";
            this.NumOfRefills.Width = 150;
            // 
            // RXName
            // 
            this.RXName.DataPropertyName = "RXName";
            this.RXName.HeaderText = "RXName";
            this.RXName.MinimumWidth = 8;
            this.RXName.Name = "RXName";
            this.RXName.Width = 150;
            // 
            // RXDosage
            // 
            this.RXDosage.DataPropertyName = "RXDosage";
            this.RXDosage.HeaderText = "RXDosage";
            this.RXDosage.MinimumWidth = 8;
            this.RXDosage.Name = "RXDosage";
            this.RXDosage.Width = 150;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuNew,
            this.cmuDelete,
            this.refillPrescriptionToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(220, 100);
            // 
            // mnuNew
            // 
            this.mnuNew.Name = "mnuNew";
            this.mnuNew.Size = new System.Drawing.Size(219, 32);
            this.mnuNew.Text = "New";
            this.mnuNew.Click += new System.EventHandler(this.mnuNew_Click);
            // 
            // cmuDelete
            // 
            this.cmuDelete.Name = "cmuDelete";
            this.cmuDelete.Size = new System.Drawing.Size(219, 32);
            this.cmuDelete.Text = "Delete";
            this.cmuDelete.Click += new System.EventHandler(this.cmuDelete_Click);
            // 
            // refillPrescriptionToolStripMenuItem
            // 
            this.refillPrescriptionToolStripMenuItem.Name = "refillPrescriptionToolStripMenuItem";
            this.refillPrescriptionToolStripMenuItem.Size = new System.Drawing.Size(219, 32);
            this.refillPrescriptionToolStripMenuItem.Text = "Refill Prescription";
            this.refillPrescriptionToolStripMenuItem.Click += new System.EventHandler(this.refillPrescriptionToolStripMenuItem_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(311, 281);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 20);
            this.label2.TabIndex = 14;
            this.label2.Text = "PrescriptionID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(451, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "Search For Patients Prescription";
            // 
            // txtPerscriptionID
            // 
            this.txtPerscriptionID.Location = new System.Drawing.Point(455, 278);
            this.txtPerscriptionID.Name = "txtPerscriptionID";
            this.txtPerscriptionID.Size = new System.Drawing.Size(100, 26);
            this.txtPerscriptionID.TabIndex = 1;
            this.txtPerscriptionID.TextChanged += new System.EventHandler(this.txtPerscriptionID_TextChanged);
            // 
            // txtPatientID
            // 
            this.txtPatientID.Location = new System.Drawing.Point(455, 211);
            this.txtPatientID.Name = "txtPatientID";
            this.txtPatientID.Size = new System.Drawing.Size(100, 26);
            this.txtPatientID.TabIndex = 0;
            this.txtPatientID.TextChanged += new System.EventHandler(this.txtPatientID_TextChanged);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(715, 211);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(114, 46);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.toolTip1.SetToolTip(this.btnSearch, "Click to Search");
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(344, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 20);
            this.label4.TabIndex = 16;
            this.label4.Text = "PatientID:";
            // 
            // btnClose
            // 
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(715, 281);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(114, 39);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "Close";
            this.toolTip1.SetToolTip(this.btnClose, "Click to Close");
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmPerscription
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(1151, 672);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPerscriptionID);
            this.Controls.Add(this.txtPatientID);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.dgvPerscription);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmPerscription";
            this.Text = "Search Prescription";
            this.Load += new System.EventHandler(this.frmPerscription_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPerscription)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvPerscription;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPerscriptionID;
        private System.Windows.Forms.TextBox txtPatientID;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuNew;
        private System.Windows.Forms.ToolStripMenuItem cmuDelete;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolStripMenuItem refillPrescriptionToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrescriptionID;
        private System.Windows.Forms.DataGridViewTextBoxColumn NumOfRefills;
        private System.Windows.Forms.DataGridViewTextBoxColumn RXName;
        private System.Windows.Forms.DataGridViewTextBoxColumn RXDosage;
    }
}