﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSFinal
{
    public partial class frmStart : Form
    {
        public frmStart()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAddPatient_Click(object sender, EventArgs e)
        {
            Form aform = new frmAddPatient();

            aform.ShowDialog();


        }

        private void btnPatientSearch_Click(object sender, EventArgs e)
        {
            Form aform = new frmSearchPatient();

            aform.ShowDialog();
        }

        private void btnAddPhysician_Click(object sender, EventArgs e)
        {
            Form aform = new frmAddPhysician();
            aform.ShowDialog();
        }

        private void btnSearchPhysicians_Click(object sender, EventArgs e)
        {
            Form aform = new frmSearchPhysician();
            aform.ShowDialog();
        }

        private void btnAddPerscription_Click(object sender, EventArgs e)
        {
            Form aform = new frmAddPerscription();

            aform.ShowDialog();
        }

        private void btnSearchPerscription_Click(object sender, EventArgs e)
        {
            Form aform = new frmPerscription();
            aform.ShowDialog();
        }

        private void btnSeeRefill_Click(object sender, EventArgs e)
        {
            Form aform = new frmRefillCheck();
            aform.ShowDialog();
        }

        private void mnuAddPatient_Click(object sender, EventArgs e)
        {
            btnAddPatient_Click(sender, e);
        }

        private void mnuAddPharmacist_Click(object sender, EventArgs e)
        {
            btnAddPhysician_Click(sender, e);
        }

        private void mnuAddPerscription_Click(object sender, EventArgs e)
        {
            btnAddPerscription_Click(sender, e);
        }

        private void mnuSearchPatient_Click(object sender, EventArgs e)
        {
            btnPatientSearch_Click(sender, e);
        }

        private void mnuSearchPharmacist_Click(object sender, EventArgs e)
        {
            btnSearchPhysicians_Click(sender, e);
        }

        private void mnuSearchPerscription_Click(object sender, EventArgs e)
        {
            btnSearchPerscription_Click(sender, e);
        }

        private void mnuSearchRefills_Click(object sender, EventArgs e)
        {
            btnSeeRefill_Click(sender, e);
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 aboutBox1 = new AboutBox1();
            aboutBox1.ShowDialog();
        }
    }
}
